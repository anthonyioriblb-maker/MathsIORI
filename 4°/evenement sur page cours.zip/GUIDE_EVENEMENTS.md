# Guide d'utilisation du système d'ÉVÉNEMENTS 📅

## Installation

1. **Remplacer les fichiers CSS et JS** par les nouveaux fichiers :
   - `classe-page.css` (nouveau)
   - `classe-page.js` (nouveau)

2. Ces fichiers sont utilisés par TOUTES les classes :
   - classe-6e.html
   - classe-5e.html
   - classe-4e.html
   - classe-3e.html

## Comment ajouter un événement

Dans votre fichier `classe-*.html`, ajoutez simplement la section `evenement` dans la configuration d'un chapitre :

```javascript
chapitre6: {
    disponible: true,
    titre: "statistiques et probabilités",
    description: "Introduction aux concepts de base des statistiques et des probabilités",
    emoji: "📊",
    cours: {
        actif: true,
        fichier: "4e-chapitre6.html"
    },
    exercices: {
        actif: false,
        items: []
    },
    quiz: {
        actif: false,
        items: []
    },
    evenement: {
        actif: true,              // true = afficher le bouton, false = masquer
        titre: "Sujet type",      // Texte du bouton (court!)
        fichier: "devoir_stat_proba.html"  // Fichier à ouvrir
    }
}
```

## Exemples d'utilisation

### Exemple 1 : Devoir à venir
```javascript
evenement: {
    actif: true,
    titre: "Devoir le 15/01",
    fichier: "devoir_pythagore.html"
}
```

### Exemple 2 : Révisions
```javascript
evenement: {
    actif: true,
    titre: "Sujet brevet",
    fichier: "sujet_brevet_2024.html"
}
```

### Exemple 3 : Contrôle
```javascript
evenement: {
    actif: true,
    titre: "DS vendredi",
    fichier: "ds_fractions.html"
}
```

### Exemple 4 : Désactiver un événement
```javascript
evenement: {
    actif: false,  // Le bouton ne s'affichera pas
    titre: "Ancien devoir",
    fichier: "ancien_devoir.html"
}
```

## Apparence du bouton

Le bouton événement apparaît avec :
- ✨ Dégradé rouge-orange (se démarque des autres boutons)
- 📅 Icône calendrier automatique
- 💫 Animation de pulsation pour attirer l'attention
- 🎨 Style unique qui ne se confond pas avec Cours/Exercices/Quiz

## Avantages

✅ Fonctionne sur TOUTES les classes (6e, 5e, 4e, 3e)
✅ Facile à activer/désactiver (actif: true/false)
✅ Se met à jour automatiquement
✅ Design attrayant qui attire l'œil des élèves
✅ Pas besoin de modifier le code à chaque fois

## Notes importantes

- Le titre du bouton doit être COURT (max 15 caractères)
- L'icône 📅 est ajoutée automatiquement
- Un seul événement par chapitre
- Pour désactiver : mettre `actif: false` au lieu de supprimer la section
